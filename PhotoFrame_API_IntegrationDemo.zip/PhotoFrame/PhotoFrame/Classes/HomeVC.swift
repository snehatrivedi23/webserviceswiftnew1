//
//  HomeVC.swift
//  PhotoFrame
//
//  Created by User Mac on 08/07/1940 Saka.
//  Copyright © 1940 User Mac. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var arrayUserList = [UserListModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.register(UINib(nibName: UserListTableViewCell.identifier, bundle: nil), forCellReuseIdentifier: UserListTableViewCell.identifier)
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 100
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //self.startAnimating()
        self.getSliderImages()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//MARK:- UICollectionView Delegate & Datasource
extension HomeVC: UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayUserList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UserListTableViewCell.identifier, for: indexPath) as! UserListTableViewCell
        cell.objUser = self.arrayUserList[indexPath.row]
        return cell
    }
    
}



//MARK:- API Request / Response
extension HomeVC
{
    func getSliderImages() {
        let parameter : Parameters = [:]
        Alamofire.request(NetworkManager.getUserList(parameter))
            .validate(contentType: ["application/json"])
            .responseJSON { response in
                print(response)
                if let responseDict = response.result.value {
                    let json = JSON(responseDict)
                    let _ = json[Constant.KeyMessage].stringValue
                    if json[Constant.KeyResult].boolValue == true {
                        let dict = responseDict as? NSDictionary
                        let arrayUser = dict![Constant.KeyData] as! [Constant.KeyJson]
                        self.arrayUserList = arrayUser.flatMap({ (user) -> [UserListModel] in
                            return [UserListModel(json: user)]
                        })
                        self.tableView.reloadData()
                        print(self.arrayUserList)
                    } else {
                        
                    }
                } else {
                    print("Something went wrong..")
                }
        }
    }
    
    
}
