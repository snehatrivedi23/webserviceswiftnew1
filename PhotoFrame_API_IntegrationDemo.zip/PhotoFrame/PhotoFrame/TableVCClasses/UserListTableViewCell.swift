//
//  UserListTableViewCell.swift
//  PhotoFrame
//
//  Created by Hardik Baraiya on 30/11/18.
//  Copyright © 2018 User Mac. All rights reserved.
//

import UIKit
import SDWebImage

class UserListTableViewCell: UITableViewCell {
    
    static let identifier = String(describing: UserListTableViewCell.self)
    
    @IBOutlet weak var labelFirstName: UILabel!
    @IBOutlet weak var labelLastName: UILabel!
    @IBOutlet weak var imageUser: UIImageView!
    
    var objUser: UserListModel? {
        didSet {
            if let user = self.objUser {
                self.labelFirstName.text = user.first_name
                self.labelLastName.text = user.last_name
                self.imageUser.sd_setImage(with: URL(string: user.avatarImage), completed: nil)
            }
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
