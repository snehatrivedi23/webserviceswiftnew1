//
//  UIViewControllerExtension.swift
//  PhotoFrame
//
//  Created by User Mac on 18/07/1940 Saka.
//  Copyright © 1940 User Mac. All rights reserved.
//

import Foundation
import NVActivityIndicatorView

extension UIViewController: NVActivityIndicatorViewable {
    
    //Variables
    var AppDelegate:AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    
    //Alert
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message:
            message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: Constant.KeyOk.uppercased(), style: .default, handler: {action in
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    

    
    
    
}
