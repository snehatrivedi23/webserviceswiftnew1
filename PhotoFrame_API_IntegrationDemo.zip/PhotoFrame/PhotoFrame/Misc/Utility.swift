//
//  Utility.swift
//  PhotoFrame
//
//  Created by User Mac on 08/07/1940 Saka.
//  Copyright © 1940 User Mac. All rights reserved.
//

import Foundation
import UIKit
@_exported import Alamofire
@_exported import SwiftyJSON


class Utility: NSObject {
    
    static func thisIsTestFunc() {
        
    }
}

