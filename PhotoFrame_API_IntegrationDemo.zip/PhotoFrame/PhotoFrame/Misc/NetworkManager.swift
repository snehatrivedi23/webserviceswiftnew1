//
//  NetworkManager.swift
//  PhotoFrame
//
//  Created by User Mac on 08/07/1940 Saka.
//  Copyright © 1940 User Mac. All rights reserved.
//

import Foundation


enum NetworkManager: URLRequestConvertible
{
    static let baseURLString = "http://www.mocky.io"
        
    static let header = ["Content-Type": "application/json",
                  "accept": "application/json"]
    
    case getUserList([String: Any])
    
    var method: HTTPMethod
    {
        switch self {
        case .getUserList:
            return .get
    
        
        }
    }
    
    
    
    
    var path: String
    {
        switch self {
        case .getUserList:
            return "/v2/5c018aac3500005300ad0a12"
            
        
        }
    }
    
    
    
    
    
    // MARK: URLRequestConvertible
    
    func asURLRequest() throws -> URLRequest
    {
        let url = try NetworkManager.baseURLString.asURL()
        
        var urlRequest = URLRequest(url: url.appendingPathComponent(path))
        urlRequest.httpMethod = method.rawValue
        urlRequest.allHTTPHeaderFields = NetworkManager.header
        
        switch self {
        case .getUserList(let parameters):
            urlRequest = try URLEncoding.default.encode(urlRequest, with: parameters)
            
         
            
            
        }
        return urlRequest
    }
    
}
