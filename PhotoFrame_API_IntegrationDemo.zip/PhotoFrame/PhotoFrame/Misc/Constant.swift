//
//  Constant.swift
//  PhotoFrame
//
//  Created by User Mac on 08/07/1940 Saka.
//  Copyright © 1940 User Mac. All rights reserved.
//

import Foundation

class Constant
{
    
    typealias KeyJson = [String: Any]
    
    //Alert
    static let KeyOk = "OK"
    static let KeyCancel = "Cancel"
    
    //API
    static let KeyData = "data"
    
    static let KeyId = "id"
    static let KeyFirstName = "first_name"
    static let KeyLastName = "last_name"
    static let KeyAvatarImageURL = "avatar"
    
    static let KeyResult = "result"
    static let KeyMessage = "message"
    
}
