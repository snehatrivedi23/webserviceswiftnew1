//
//  Model.swift
//  PhotoFrame
//
//  Created by User Mac on 08/07/1940 Saka.
//  Copyright © 1940 User Mac. All rights reserved.
//


import Foundation
import UIKit

class UserListModel
{
    var id = ""
    var first_name = ""
    var last_name = ""
    var avatarImage = ""
    
    init(){}
    init(json: Constant.KeyJson){
        self.id = (json[Constant.KeyId] as? String) ?? ""
        self.first_name = (json[Constant.KeyFirstName] as? String) ?? ""
        self.last_name = (json[Constant.KeyLastName] as? String) ?? ""
        self.avatarImage = (json[Constant.KeyAvatarImageURL] as? String) ?? ""
    }
    
}



