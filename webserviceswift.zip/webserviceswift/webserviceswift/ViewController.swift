//
//  ViewController.swift
//  webserviceswift
//
//  Created by Priyanka Patel on 06/10/17.
//  Copyright © 2017 Priyanka Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet var tabledata: UITableView!
    var referencearay:NSMutableArray = NSMutableArray()
    
    var referencearay2:NSMutableArray = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //let urlString:NSURL =  NSURL(string: "http://www.4ambuch.com/purepolitics_api/getStates.php")!
        let urlString = "http://www.4ambuch.com/purepolitics_api/getStates.php"
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!) as! [String:Any]
                    print(parsedData)
                    self.referencearay = parsedData["ministries"] as! NSMutableArray
                    self.referencearay2 = parsedData["states"] as! NSMutableArray
               
                    print(self.referencearay)
                      print(self.referencearay2)
                    
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            
            }.resume()
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
     func numberOfSections(in tableView: UITableView) -> Int
    {
       return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
       if(section == 1)
       {
        return referencearay.count
        }
        else
       {
        return referencearay2.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! webTableViewCell
        if indexPath.section == 1
        {
             cell.lblstatae.text = referencearay[indexPath.row] as? String
        }
        else
        {
             cell.lblstatae.text = referencearay2[indexPath.row] as? String
        }
        return cell
        }

}

