//
//  webTableViewCell.swift
//  webserviceswift
//
//  Created by Priyanka Patel on 06/10/17.
//  Copyright © 2017 Priyanka Patel. All rights reserved.
//

import UIKit

class webTableViewCell: UITableViewCell {

    @IBOutlet var lblstatae: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
